from flask import Flask, render_template, jsonify
import json
import threading
import paho.mqtt.client as mqtt

app = Flask(__name__)

MQTT_HOST = "127.0.0.1"
MQTT_PORT = 1883
MQTT_TOPIC = "channel1"

sensor_data = {
    "t": None,
    "h": None,
    "p": None,
    "l": None,
    "online": False
}

def on_connect(client, userdata, flags, reason_code, properties=None):
    print("MQTT connected:", reason_code)
    client.subscribe(MQTT_TOPIC)

def on_message(client, userdata, msg):
    global sensor_data
    try:
        payload = json.loads(msg.payload.decode("utf-8"))

        sensor_data = {
            "t": payload.get("t"),
            "h": payload.get("h"),
            "p": payload.get("p"),
            "l": payload.get("l"),
            "online": True
        }

        print("Received:", sensor_data)

    except Exception as e:
        print("MQTT message error:", e)

mqtt_client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2)
mqtt_client.on_connect = on_connect
mqtt_client.on_message = on_message

def mqtt_worker():
    mqtt_client.connect(MQTT_HOST, MQTT_PORT, 60)
    mqtt_client.loop_forever()

threading.Thread(target=mqtt_worker, daemon=True).start()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/data")
def api_data():
    return jsonify(sensor_data)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)
