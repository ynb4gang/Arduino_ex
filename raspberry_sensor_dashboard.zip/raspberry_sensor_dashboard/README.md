# Raspberry Pi Sensor Dashboard

Arduino -> WiFi -> MQTT -> Raspberry Pi -> Flask Web UI

## MQTT topic

channel1

Expected payload:

{"t":"23", "h":"45", "p":"760", "l":"520"}

## Run

```bash
sudo apt update
sudo apt install -y mosquitto mosquitto-clients python3-venv

sudo systemctl enable mosquitto
sudo systemctl start mosquitto

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

python app.py
```

Open:

http://RASPBERRY_PI_IP:5000
